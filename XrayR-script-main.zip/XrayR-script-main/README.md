# XRayR
A Xray backend framework that can easily support many panels.

一个基于Xray的后端框架，支持V2ay,Trojan,Shadowsocks协议，极易扩展，支持多面板对接

Find the source code here: [youzi3/XrayR](https://github.com/youzi3/XrayR)

如对脚本不放心，可使用此沙箱先测一遍再使用：https://killercoda.com/playgrounds/scenario/ubuntu

# 详细使用教程

[教程](https://crackair.gitbook.io/xrayr-project/)

# 一键安装

```
wget -N https://raw.githubusercontents.com/youzi3/XrayR-script/master/install.sh && bash install.sh
```
OR
```
bash <(curl -Ls https://raw.githubusercontents.com/youzi3/XrayR-script/master/install.sh)
```
